// RecogMQDF.h: interface for the CRecogMQDF class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

//#include "typedefine.h"

int RecogMQDFCharImg(BYTE* pImg, int w, int h);
// BOOL	LoadMQDFDic(BYTE* pDic,DWORD dicLen);
// BOOL	ReleaseMQDFEngine();

// !defined(AFX_RECOGMQDF_H__BC28A219_47BA_46D1_8493_27729A54CE6F__INCLUDED_)
